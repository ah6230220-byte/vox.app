package com.voxmixer.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private val engine = AudioEngine()
    private var pendingStart: (() -> Unit)? = null
    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) pendingStart?.invoke()
        pendingStart = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var active by remember { mutableStateOf(false) }
            var gain by remember { mutableFloatStateOf(1.4f) }
            var limiter by remember { mutableFloatStateOf(0.88f) }
            var status by remember { mutableStateOf("جاهز للتجربة") }

            MaterialTheme(colorScheme = darkColorScheme(
                primary = Color(0xFFB69CFF), background = Color(0xFF101116),
                surface = Color(0xFF1C1E27), onSurface = Color.White
            )) {
                Column(
                    Modifier.fillMaxSize().background(Color(0xFF101116))
                        .verticalScroll(rememberScrollState()).padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    Text("VOX MIXER", style = MaterialTheme.typography.headlineLarge, color = Color.White)
                    Text("PRO AUDIO • ANDROID MVP", color = Color(0xFFB69CFF))
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1E27)),
                        shape = RoundedCornerShape(22.dp)) {
                        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text(if (active) "MIC ENGINE ACTIVE" else "MIC ENGINE STANDBY", style = MaterialTheme.typography.titleLarge)
                            Text(status, color = Color.LightGray)
                            Button(
                                modifier = Modifier.fillMaxWidth(),
                                onClick = {
                                    if (active) {
                                        engine.stop(); active = false; status = "تم إيقاف المعالجة"
                                    } else {
                                        val startNow = {
                                            try {
                                                engine.gain = gain
                                                engine.limiter = limiter
                                                engine.start()
                                                active = true
                                                status = "يعالج المايك محلياً — استخدم سماعة"
                                            } catch (e: Exception) { status = "تعذر تشغيل الصوت: ${e.message}" }
                                        }
                                        if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startNow()
                                        else { pendingStart = startNow; permission.launch(Manifest.permission.RECORD_AUDIO) }
                                    }
                                }
                            ) { Text(if (active) "إيقاف المكسر" else "تشغيل اختبار المايك") }
                        }
                    }
                    Text("ULTRA VOICE GAIN", color = Color.White, style = MaterialTheme.typography.titleMedium)
                    Text("قوة المعالجة: ${(gain * 100).toInt()}%", color = Color(0xFFB69CFF))
                    Slider(value = gain, onValueChange = { gain = it; engine.gain = it },
                        valueRange = 0.5f..3.0f, enabled = !active.not() || active)
                    Text("LIMITER / منع التشويه", color = Color.White, style = MaterialTheme.typography.titleMedium)
                    Text("${(limiter * 100).toInt()}% من سعة الإشارة", color = Color(0xFFB69CFF))
                    Slider(value = limiter, onValueChange = { limiter = it; engine.limiter = it }, valueRange = 0.5f..0.95f)
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1E27))) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("مهم قبل الاختبار", color = Color.White, style = MaterialTheme.typography.titleMedium)
                            Text("• استخدم سماعة رأس لتجنب الصفير والتغذية الراجعة.\n• ابدأ بمستوى صوت منخفض وارفعه تدريجياً.\n• هذه النسخة تسمعك الصوت المعالج محلياً فقط؛ لا ترسله إلى بث تيك توك أو مكالمة تليجرام.", color = Color.LightGray)
                        }
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        engine.stop()
        super.onDestroy()
    }
}
