package com.voxmixer.app

import android.media.*
import kotlin.math.abs
import kotlin.math.tanh

/**
 * Local microphone monitor for MVP testing.
 * It processes mic audio and plays it to the selected output (use headphones).
 * Android does not provide a general API for injecting this stream into TikTok/Telegram.
 */
class AudioEngine {
    @Volatile private var running = false
    @Volatile var gain: Float = 1.4f
    @Volatile var limiter: Float = 0.88f
    private var recorder: AudioRecord? = null
    private var player: AudioTrack? = null
    private var worker: Thread? = null

    fun start() {
        if (running) return
        val rate = 48000
        val minIn = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val minOut = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        require(minIn > 0 && minOut > 0) { "Audio device not supported" }
        val bufferBytes = maxOf(minIn, minOut, 4096)
        val input = AudioRecord(
            MediaRecorder.AudioSource.MIC, rate,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferBytes
        )
        val output = AudioTrack(
            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build(),
            AudioFormat.Builder().setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT).build(),
            bufferBytes, AudioTrack.MODE_STREAM, AudioManager.AUDIO_SESSION_ID_GENERATE
        )
        input.startRecording()
        output.play()
        recorder = input
        player = output
        running = true
        worker = Thread {
            val samples = ShortArray(bufferBytes / 2)
            while (running) {
                val count = input.read(samples, 0, samples.size, AudioRecord.READ_BLOCKING)
                if (count > 0) {
                    val g = gain.coerceIn(0.5f, 3.0f)
                    val ceiling = limiter.coerceIn(0.50f, 0.95f)
                    for (i in 0 until count) {
                        val x = (samples[i] / 32768f) * g
                        val shaped = tanh(x * 1.15f) / tanh(1.15f)
                        val limited = shaped.coerceIn(-ceiling, ceiling)
                        samples[i] = (limited * 32767f).toInt().toShort()
                    }
                    output.write(samples, 0, count, AudioTrack.WRITE_BLOCKING)
                }
            }
        }.apply { name = "VoxAudioDSP"; start() }
    }

    fun stop() {
        running = false
        worker?.join(500)
        worker = null
        recorder?.runCatching { stop(); release() }
        player?.runCatching { pause(); flush(); stop(); release() }
        recorder = null
        player = null
    }

    fun isRunning() = running
}
